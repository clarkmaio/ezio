

# Ezio
## an altair wrapper

I've decided to dedicate my life to make people stop using plotly