

import polars as pl

def test_timeserieschart():
    pass